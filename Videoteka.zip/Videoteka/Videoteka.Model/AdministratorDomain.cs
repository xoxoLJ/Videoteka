﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;
using Videoteka.DataModel;

namespace Videoteka.Model
{
    public class AdministratorDomain : OsobaDomain
    {
        [JsonPropertyName("administratorID")]
        public int AdministratorID { get; set; }
        [JsonPropertyName("datumZaposlenja")]
        public DateTime? DatumZaposlenja { get; set; }
    }
}
