﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace Videoteka.Model
{
    public class FilmDomain
    {
        [JsonPropertyName("filmID")]
        public int FilmID { get; set; }
        [JsonPropertyName("pristup")]
        public bool Pristup { get; set; }
        [JsonPropertyName("naziv")]
        public string Naziv { get; set; }
        [JsonPropertyName("opis")]
        public string Opis { get; set; }
        [JsonPropertyName("zanrID")]
        public int ZanrID { get; set; }
        [JsonPropertyName("podudaranje")]
        public string Podudaranje { get; set; }
        [JsonPropertyName("godina")]
        public string Godina { get; set; }
        [JsonPropertyName("trajanje")]
        public string Trajanje { get; set; }
        [JsonPropertyName("ogranicenje")]
        public string Ogranicenje { get; set; }
        [JsonPropertyName("redatelji")]
        public string Redatelji { get; set; }
        [JsonPropertyName("glumci")]
        public string Glumci { get; set; }
        [JsonPropertyName("scenaristi")]
        public string Scenaristi { get; set; }
        [JsonPropertyName("zanrovi")]
        public string Zanrovi { get; set; }

        public ZanrDomain Zanr { get; set; }
    }
}
