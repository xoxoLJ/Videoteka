﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace Videoteka.Model
{
    public class GledateljDomain : OsobaDomain
    {
        [JsonPropertyName("gledateljID")]
        public int GledateljID { get; set; }
        [JsonPropertyName("datumRegistracije")]
        public DateTime? DatumRegistracije { get; set; }
    }
}
