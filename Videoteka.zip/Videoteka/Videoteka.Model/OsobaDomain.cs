﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json.Serialization;

namespace Videoteka.Model
{
    public class OsobaDomain
    {
        [JsonPropertyName("osobaID")]
        public int OsobaID { get; set; }
        [JsonPropertyName("pristup")]
        public bool Pristup { get; set; }
        [JsonPropertyName("ime")]
        public string Ime { get; set; }
        [JsonPropertyName("prezime")]
        public string Prezime { get; set; }
        [JsonPropertyName("email")]
        public string Email { get; set; }
        [JsonPropertyName("lozinka")]
        public string Lozinka { get; set; }

        public AdministratorDomain Administrator { get; set; }
        public GledateljDomain Gledatelj { get; set; }
    }
}
