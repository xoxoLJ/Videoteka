﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace Videoteka.Model
{
    public class SkladisteDomain
    {
        [JsonPropertyName("skladisteID")]
        public int SkladisteID { get; set; }
        [JsonPropertyName("filmID")]
        public int FilmID { get; set; }
        [JsonPropertyName("kolicina")]
        public int Kolicina { get; set; }

        public FilmDomain Film { get; set; }
    }
}
