﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace Videoteka.Model
{
    public class ZanrDomain
    {
        [JsonPropertyName("zanrID")]
        public int ZanrID { get; set; }
        [JsonPropertyName("naziv")]
        public string Naziv { get; set; }

        public List<FilmDomain> Filmovi { get; set; }
    }
}
