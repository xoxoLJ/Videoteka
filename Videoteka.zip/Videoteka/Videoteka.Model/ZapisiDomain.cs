﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace Videoteka.Model
{
    public class ZapisiDomain
    {
        [JsonPropertyName("zapisID")]
        public int ZapisID { get; set; }
        [JsonPropertyName("filmID")]
        public int FilmID { get; set; }
        [JsonPropertyName("gledateljID")]
        public int GledateljID { get; set; }
        [JsonPropertyName("vrijemeIzdavanja")]
        public DateTime? VrijemeIzdavanja { get; set; }
        [JsonPropertyName("vrijemePovrata")]
        public string VrijemePovrata { get; set; }

        public FilmDomain Film { get; set; }
        public GledateljDomain Gledatelj { get; set; }
    }
}
