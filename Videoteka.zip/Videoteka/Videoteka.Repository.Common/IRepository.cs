﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Videoteka.Model;
using Videoteka.DataModel;

namespace Videoteka.Repository.Common
{
    public interface IRepository
    {
        //ISPIS DOMENA
        IEnumerable<OsobaDomain> GetAllOsoba();
        IEnumerable<GledateljDomain> GetAllGledatelj();
        IEnumerable<AdministratorDomain> GetAllAdministrator();
        IEnumerable<ZanrDomain> GetAllZanr();
        IEnumerable<FilmDomain> GetAllFilm();
        IEnumerable<FilmDomain> GetAllFilmRandom();
        IEnumerable<SkladisteDomain> GetAllSkladiste();
        IEnumerable<ZapisiDomain> GetAllZapisi();


        //ISPIS PO ID-U
        OsobaDomain GetOsobaById(int osobaId);
        GledateljDomain GetGledateljById(int gledateljId);
        AdministratorDomain GetAdministratorById(int administratorId);
        ZanrDomain GetZanrById(int zanrId);
        FilmDomain GetFilmById(int filmId);
        FilmDomain GetFilmByZanrId(int filmZanrId);
        FilmDomain GetFilmByIdAndZanrId(int zanrId, int filmId);
        SkladisteDomain GetSkladisteById(int skladisteId);
        SkladisteDomain GetSkladisteByFilmId(int skladisteFilmId);
        SkladisteDomain GetSkladisteByKolicina(int skladisteKolicina);
        ZapisiDomain GetZapisiById(int zapisiId);
        ZapisiDomain GetZapisiByFilmId(int zapisiFilmId);
        ZapisiDomain GetZapisiByGledateljId(int zapisiGledateljId);
        ZapisiDomain GetZapisiByVrijemeIzdavanja(DateTime zapisiVrijemeIzdavanja);
        ZapisiDomain GetZapisiByVrijemePovrata(string zapisiVrijemePovrata);


        //DODAVANJE
        Task<bool> DodajOsoba(OsobaDomain osobaAdd);
        Task<bool> DodajOsobaGledatelj(OsobaDomain osobaAddGledatelj);
        Task<bool> DodajOsobaAdministrator(OsobaDomain osobaAddAdministrator);
        Task<bool> DodajGledatelj(GledateljDomain gledateljAdd);
        Task<bool> DodajAdministrator(AdministratorDomain administratorAdd);
        Task<bool> DodajFilm(FilmDomain filmAdd);
        Task<bool> DodajSkladiste(SkladisteDomain skladisteAdd);
        Task<bool> DodajZapisi(ZapisiDomain zapisiAdd);


        //AZURIRANJE
        Task<bool> UpdateOsoba(OsobaDomain osobaUpdate);
        Task<bool> UpdateGledatelj(GledateljDomain gledateljUpdate);
        Task<bool> UpdateAdministrator(AdministratorDomain administratorUpdate);
        Task<bool> UpdateFilm(FilmDomain filmUpdate);
        Task<bool> UpdateSkladiste(SkladisteDomain skladisteUpdate);
        Task<bool> UpdateZapisi(ZapisiDomain zapisiUpdate);


        //BRISANJE
        Task<bool> DeleteOsoba(OsobaDomain osobaDelete);
        Task<bool> DeleteFilm(FilmDomain filmDelete);
    }
}
