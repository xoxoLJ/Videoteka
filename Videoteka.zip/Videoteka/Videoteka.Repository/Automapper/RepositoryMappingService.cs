﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using AutoMapper;
using Videoteka.DataModel;
using Videoteka.Model;

namespace Videoteka.Repository.Automapper
{
    public class RepositoryMappingService : IRepositoryMappingService
    {
        public Mapper mapper;
        //private readonly IMapper _mapper;

        public RepositoryMappingService()
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<Film, FilmDomain>()
                    .ForMember(dest => dest.ZanrID, opt => opt.MapFrom(src => src.Zanr.ZanrID))
                ; ;
                cfg.CreateMap<FilmDomain, Film>();

                cfg.CreateMap<Zanr, ZanrDomain>();
                cfg.CreateMap<ZanrDomain, Zanr>();

                cfg.CreateMap<Osoba, OsobaDomain>();
                cfg.CreateMap<OsobaDomain, Osoba>();

                cfg.CreateMap<Administrator, AdministratorDomain>()
                    .ForMember(dest => dest.AdministratorID, opt => opt.MapFrom(src => src.AdministratorID))
                    .ForMember(dest => dest.DatumZaposlenja, opt => opt.MapFrom(src => src.DatumZaposlenja))
                    ; ;
                cfg.CreateMap<AdministratorDomain, Administrator>();

                cfg.CreateMap<Gledatelj, GledateljDomain>()
                    .ForMember(dest => dest.GledateljID, opt => opt.MapFrom(src => src.GledateljID))
                    .ForMember(dest => dest.DatumRegistracije, opt => opt.MapFrom(src => src.DatumRegistracije))
                    ; ;
                cfg.CreateMap<GledateljDomain, Gledatelj>();

                cfg.CreateMap<SkladisteDomain, Skladiste>()
                    .ForMember(dest => dest.Kolicina, opt => opt.MapFrom(src => src.Kolicina))
                    ; ;
                cfg.CreateMap<Skladiste, SkladisteDomain>();

                cfg.CreateMap<Zapisi, ZapisiDomain>()
                    .ForMember(dest => dest.VrijemeIzdavanja, opt => opt.MapFrom(src => src.VrijemeIzdavanja))
                    .ForMember(dest => dest.VrijemePovrata, opt => opt.MapFrom(src => src.VrijemePovrata))
                    ; ;
                cfg.CreateMap<ZapisiDomain, Zapisi>();
            });

            mapper = new Mapper(config);
            //_mapper = config.CreateMapper();
        }

        public TDestination Map<TDestination>(object source)
        {
            return mapper.Map<TDestination>(source);
            //if (source == null) throw new ArgumentNullException(nameof(source));
            //return _mapper.Map<TDestination>(source);
        }
    }
}
