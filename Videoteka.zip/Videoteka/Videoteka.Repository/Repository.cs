﻿using Videoteka.DataModel;
using Videoteka.Model;
using Videoteka.Repository.Automapper;
using Videoteka.Repository.Common;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Drawing;
using System.Runtime.InteropServices;

namespace Videoteka.Repository
{
    public class Repository : IRepository
    {
        private readonly VideotekaDbContext _context;
        private readonly IRepositoryMappingService _mappingService;

        public Repository(VideotekaDbContext context, IRepositoryMappingService mappingService)
        {
            _context = context;
            _mappingService = mappingService;
        }


        //ISPIS DOMENA
        public IEnumerable<OsobaDomain> GetAllOsoba()
        {
            var osobe = _context.Osoba.ToList();

            var osobaDomain = _mappingService.Map<IEnumerable<OsobaDomain>>(osobe);
            return osobaDomain;
        }
        public IEnumerable<GledateljDomain> GetAllGledatelj()
        {
            var gledatelji = _context.Gledatelj
                                        .Include(b => b.Osoba)
                                        .ToList();

            var gledateljDomain = _mappingService.Map<IEnumerable<GledateljDomain>>(gledatelji);
            return gledateljDomain;
        }
        public IEnumerable<AdministratorDomain> GetAllAdministrator()
        {
            var administratori = _context.Administrator
                                        .Include(b => b.Osoba)
                                        .ToList();

            var administratorDomain = _mappingService.Map<IEnumerable<AdministratorDomain>>(administratori);
            return administratorDomain;
        }
        public IEnumerable<ZanrDomain> GetAllZanr()
        {
            var zanrovi = _context.Zanr.ToList();

            var zanrDomain = _mappingService.Map<IEnumerable<ZanrDomain>>(zanrovi);
            return zanrDomain;
        }
        public IEnumerable<FilmDomain> GetAllFilm()
        {
            var filmovi = _context.Film
                                        .Include(b => b.Zanr)
                                        .ToList();

            var filmDomain = _mappingService.Map<IEnumerable<FilmDomain>>(filmovi);
            return filmDomain;
        }
        public IEnumerable<FilmDomain> GetAllFilmRandom()
        {
            var filmoviRandom = _context.Film
                                        .Include(b => b.Zanr)
                                        .OrderBy(r => Guid.NewGuid())
                                        .Take(10)
                                        .ToList();

            var filmRandomDomain = _mappingService.Map<IEnumerable<FilmDomain>>(filmoviRandom);
            return filmRandomDomain;
        }
        public IEnumerable<SkladisteDomain> GetAllSkladiste()
        {
            var skladista = _context.Skladiste
                                        .Include(b => b.Film)
                                        .ToList();

            var skladisteDomain = _mappingService.Map<IEnumerable<SkladisteDomain>>(skladista);
            return skladisteDomain;
        }
        public IEnumerable<ZapisiDomain> GetAllZapisi()
        {
            var zapisi = _context.Zapisi
                                        .Include(b => b.Film)
                                        .Include(b => b.Gledatelj)
                                        .ToList();

            var zapisiDomain = _mappingService.Map<IEnumerable<ZapisiDomain>>(zapisi);
            return zapisiDomain;
        }


        //ISPIS PO ID-U
        public OsobaDomain GetOsobaById(int osobaId)
        {
            var osoba = _context.Osoba.FirstOrDefault(b => b.OsobaID == osobaId);

            if (osoba != null)
            {
                var osobaDomain = _mappingService.Map<OsobaDomain>(osoba);
                return osobaDomain;
            }
            else
            {
                return null;
            }
        }
        public GledateljDomain GetGledateljById(int gledateljId)
        {
            var gledatelj = _context.Gledatelj
                                        .Include(b => b.Osoba)
                                        .FirstOrDefault(b => b.Osoba.OsobaID == gledateljId);

            if (gledatelj != null)
            {
                var gledateljDomain = _mappingService.Map<GledateljDomain>(gledatelj);
                return gledateljDomain;
            }
            else
            {
                return null;
            }
        }
        public AdministratorDomain GetAdministratorById(int administratorId)
        {
            var administrator = _context.Administrator
                                        .Include(b => b.Osoba)
                                        .FirstOrDefault(b => b.Osoba.OsobaID == administratorId);

            if (administrator != null)
            {
                var administratorDomain = _mappingService.Map<AdministratorDomain>(administrator);
                return administratorDomain;
            }
            else
            {
                return null;
            }
        }
        public ZanrDomain GetZanrById(int zanrId)
        {
            var zanr = _context.Zanr.FirstOrDefault(b => b.ZanrID == zanrId);

            if (zanr != null)
            {
                var zanrDomain = _mappingService.Map<ZanrDomain>(zanr);
                return zanrDomain;
            }
            else
            {
                return null;
            }
        }
        public FilmDomain GetFilmById(int filmId)
        {
            var film = _context.Film
                                        .Include(b => b.Zanr)
                                        .FirstOrDefault(b => b.FilmID == filmId);

            if (film != null)
            {
                var filmDomain = _mappingService.Map<FilmDomain>(film);
                return filmDomain;
            }
            else
            {
                return null;
            }
        }
        public FilmDomain GetFilmByZanrId(int filmZanrId)
        {
            var filmZanr = _context.Film
                                        .Include(b => b.Zanr)
                                        .Where(b => b.Zanr.ZanrID == filmZanrId)
                                        .ToList();

            if (filmZanr != null)
            {
                var filmZanrDomain = _mappingService.Map<FilmDomain>(filmZanr);
                return filmZanrDomain;
            }
            else
            {
                return null;
            }
        }
        public FilmDomain GetFilmByIdAndZanrId(int zanrId, int filmId)
        {
            var filmAndZanr = _context.Film
                                        .Include(b => b.Zanr)
                                        .FirstOrDefault(b => b.FilmID == filmId && b.Zanr.ZanrID == zanrId);

            if (filmAndZanr != null)
            {
                var filmAndZanrDomain = _mappingService.Map<FilmDomain>(filmAndZanr);
                return filmAndZanrDomain;
            }
            else
            {
                return null;
            }
        }
        public SkladisteDomain GetSkladisteById(int skladisteId)
        {
            var skladiste = _context.Skladiste
                                        .Include(b => b.Film)
                                        .FirstOrDefault(b => b.SkladisteID == skladisteId);

            if (skladiste != null)
            {
                var skladisteDomain = _mappingService.Map<SkladisteDomain>(skladiste);
                return skladisteDomain;
            }
            else
            {
                return null;
            }
        }
        public SkladisteDomain GetSkladisteByFilmId(int skladisteFilmId)
        {
            var skladisteFilm = _context.Skladiste
                                        .Include(b => b.Film)
                                        .FirstOrDefault(b => b.Film.FilmID == skladisteFilmId);

            if (skladisteFilm != null)
            {
                var skladisteFilmDomain = _mappingService.Map<SkladisteDomain>(skladisteFilm);
                return skladisteFilmDomain;
            }
            else
            {
                return null;
            }
        }
        public SkladisteDomain GetSkladisteByKolicina(int skladisteKolicina)
        {
            var skladisteKol = _context.Skladiste
                                        .Include(b => b.Film)
                                        .Where(b => b.Kolicina == skladisteKolicina)
                                        .ToList();

            if (skladisteKol != null)
            {
                var skladisteKolDomain = _mappingService.Map<SkladisteDomain>(skladisteKol);
                return skladisteKolDomain;
            }
            else
            {
                return null;
            }
        }
        public ZapisiDomain GetZapisiById(int zapisiId)
        {
            var zapis = _context.Zapisi
                                        .Include(b => b.Film)
                                        .Include(b => b.Gledatelj)
                                        .FirstOrDefault(b => b.ZapisID == zapisiId);

            if (zapis != null)
            {
                var zapisDomain = _mappingService.Map<ZapisiDomain>(zapis);
                return zapisDomain;
            }
            else
            {
                return null;
            }
        }
        public ZapisiDomain GetZapisiByFilmId(int zapisiFilmId)
        {
            var zapisFilm = _context.Zapisi
                                        .Include(b => b.Film)
                                        .Include(b => b.Gledatelj)
                                        .Where(b => b.Film.FilmID == zapisiFilmId)
                                        .ToList();

            if (zapisFilm != null)
            {
                var zapisFilmDomain = _mappingService.Map<ZapisiDomain>(zapisFilm);
                return zapisFilmDomain;
            }
            else
            {
                return null;
            }
        }
        public ZapisiDomain GetZapisiByGledateljId(int zapisiGledateljId)
        {
            var zapisGledatelj = _context.Zapisi
                                        .Include(b => b.Film)
                                        .Include(b => b.Gledatelj)
                                        .Where(b => b.Gledatelj.GledateljID == zapisiGledateljId)
                                        .ToList();

            if (zapisGledatelj != null)
            {
                var zapisGledateljDomain = _mappingService.Map<ZapisiDomain>(zapisGledatelj);
                return zapisGledateljDomain;
            }
            else
            {
                return null;
            }
        }
        public ZapisiDomain GetZapisiByVrijemeIzdavanja(DateTime zapisiVrijemeIzdavanja)
        {
            var zapisIzdavanje = _context.Zapisi
                                        .Include(b => b.Film)
                                        .Include(b => b.Gledatelj)
                                        .Where(b => b.VrijemeIzdavanja.HasValue && b.VrijemeIzdavanja.Value.Date == zapisiVrijemeIzdavanja.Date)
                                        .ToList();

            if (zapisIzdavanje != null)
            {
                var zapisIzdavanjeDomain = _mappingService.Map<ZapisiDomain>(zapisIzdavanje);
                return zapisIzdavanjeDomain;
            }
            else
            {
                return null;
            }
        }
        public ZapisiDomain GetZapisiByVrijemePovrata(string zapisiVrijemePovrata)
        {
            var zapisPovrat = _context.Zapisi
                                        .Include(b => b.Film)
                                        .Include(b => b.Gledatelj)
                                        .Where(b => b.VrijemePovrata != null && DateTime.Parse(b.VrijemePovrata).Date == DateTime.Parse(zapisiVrijemePovrata).Date)
                                        .ToList();

            if (zapisPovrat != null)
            {
                var zapisPovratDomain = _mappingService.Map<ZapisiDomain>(zapisPovrat);
                return zapisPovratDomain;
            }
            else
            {
                return null;
            }
        }


        //DODAVANJE
        public async Task<bool> DodajOsoba(OsobaDomain osobaAdd)
        {
            try
            {
                EntityEntry<Osoba> osoba = await _context.Osoba.AddAsync(_mappingService.Map<Osoba>(osobaAdd));
                await _context.SaveChangesAsync();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public async Task<bool> DodajOsobaGledatelj(OsobaDomain osobaAddGledatelj)
        {
            try
            {
                EntityEntry<Osoba> osobaGledatelj = await _context.Osoba.AddAsync(_mappingService.Map<Osoba>(osobaAddGledatelj));
                await _context.SaveChangesAsync();

                GledateljDomain gledatelj = new GledateljDomain
                {
                    GledateljID = osobaAddGledatelj.OsobaID,
                    OsobaID = osobaAddGledatelj.OsobaID,
                    DatumRegistracije = DateTime.Now
                };

                await DodajGledatelj(gledatelj);

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public async Task<bool> DodajOsobaAdministrator(OsobaDomain osobaAddAdministrator)
        {
            try
            {
                EntityEntry<Osoba> osobaAdministrator = await _context.Osoba.AddAsync(_mappingService.Map<Osoba>(osobaAddAdministrator));
                await _context.SaveChangesAsync();

                AdministratorDomain administrator = new AdministratorDomain
                {
                    AdministratorID = osobaAddAdministrator.OsobaID,
                    OsobaID = osobaAddAdministrator.OsobaID,
                    DatumZaposlenja = DateTime.Now
                };

                await DodajAdministrator(administrator);

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public async Task<bool> DodajGledatelj(GledateljDomain gledateljAdd)
        {
            try
            {
                EntityEntry<Gledatelj> gledatelj = await _context.Gledatelj.AddAsync(_mappingService.Map<Gledatelj>(gledateljAdd));
                await _context.SaveChangesAsync();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public async Task<bool> DodajAdministrator(AdministratorDomain administratorAdd)
        {
            try
            {
                EntityEntry<Administrator> administrator = await _context.Administrator.AddAsync(_mappingService.Map<Administrator>(administratorAdd));
                await _context.SaveChangesAsync();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public async Task<bool> DodajFilm(FilmDomain filmAdd)
        {
            try
            {
                EntityEntry<Film> film = await _context.Film.AddAsync(_mappingService.Map<Film>(filmAdd));
                await _context.SaveChangesAsync();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public async Task<bool> DodajSkladiste(SkladisteDomain skladisteAdd)
        {
            try
            {
                EntityEntry<Skladiste> skladiste = await _context.Skladiste.AddAsync(_mappingService.Map<Skladiste>(skladisteAdd));
                await _context.SaveChangesAsync();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public async Task<bool> DodajZapisi(ZapisiDomain zapisiAdd)
        {
            try
            {
                EntityEntry<Zapisi> zapisi = await _context.Zapisi.AddAsync(_mappingService.Map<Zapisi>(zapisiAdd));
                await _context.SaveChangesAsync();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }


        //AZURIRANJE
        public async Task<bool> UpdateOsoba(OsobaDomain osobaUpdate)
        {
            try
            {
                Osoba osoba1 = await _context.Osoba.FindAsync(osobaUpdate.OsobaID);
                if (osoba1 != null)
                {
                    osoba1.Ime = osobaUpdate.Ime ?? osoba1.Ime;
                    osoba1.Prezime = osobaUpdate.Prezime ?? osoba1.Prezime;
                    osoba1.Email = osobaUpdate.Email ?? osoba1.Email;
                    osoba1.Lozinka = osobaUpdate.Lozinka ?? osoba1.Lozinka;

                    _context.Entry(osoba1).State = EntityState.Modified;

                    await _context.SaveChangesAsync();
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }
        public async Task<bool> UpdateGledatelj(GledateljDomain gledateljUpdate)
        {
            try
            {
                Gledatelj gledatelj1 = await _context.Gledatelj.FindAsync(gledateljUpdate.GledateljID);
                if (gledatelj1 != null)
                {
                    gledatelj1.DatumRegistracije = gledateljUpdate.DatumRegistracije ?? gledatelj1.DatumRegistracije;

                    _context.Entry(gledatelj1).State = EntityState.Modified;

                    await _context.SaveChangesAsync();
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }
        public async Task<bool> UpdateAdministrator(AdministratorDomain administratorUpdate)
        {
            try
            {
                Administrator administrator1 = await _context.Administrator.FindAsync(administratorUpdate.AdministratorID);
                if (administrator1 != null)
                {
                    administrator1.DatumZaposlenja = administratorUpdate.DatumZaposlenja ?? administrator1.DatumZaposlenja;

                    _context.Entry(administrator1).State = EntityState.Modified;

                    await _context.SaveChangesAsync();
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }
        public async Task<bool> UpdateFilm(FilmDomain filmUpdate)
        {
            try
            {
                Film film1 = await _context.Film.FindAsync(filmUpdate.FilmID);
                if (film1 != null)
                {
                    film1.Naziv = filmUpdate.Naziv ?? film1.Naziv;
                    film1.Opis = filmUpdate.Opis ?? film1.Opis;

                    _context.Entry(film1).State = EntityState.Modified;

                    await _context.SaveChangesAsync();
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }
        public async Task<bool> UpdateSkladiste(SkladisteDomain skladisteUpdate)
        {
            try
            {
                Skladiste skladiste1 = await _context.Skladiste.FindAsync(skladisteUpdate.SkladisteID);
                if (skladiste1 != null)
                {
                    if (skladisteUpdate.Kolicina >= 0)
                    {
                        skladiste1.Kolicina = skladisteUpdate.Kolicina;

                        _context.Entry(skladiste1).State = EntityState.Modified;

                        await _context.SaveChangesAsync();
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }
        public async Task<bool> UpdateZapisi(ZapisiDomain zapisiUpdate)
        {
            try
            {
                Zapisi zapisi1 = await _context.Zapisi.FindAsync(zapisiUpdate.ZapisID);
                if (zapisi1 != null)
                {
                    zapisi1.VrijemePovrata = DateTime.Now.ToString("yyyy-MM-dd");

                    _context.Entry(zapisi1).State = EntityState.Modified;

                    await _context.SaveChangesAsync();
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }


        //BRISANJE
        public async Task<bool> DeleteOsoba(OsobaDomain osobaDelete)
        {
            try
            {
                Osoba osoba1 = await _context.Osoba.FindAsync(osobaDelete.OsobaID);
                if (osoba1 != null)
                {
                    osoba1.Pristup = false;

                    _context.Entry(osoba1).State = EntityState.Modified;

                    await _context.SaveChangesAsync();
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }
        public async Task<bool> DeleteFilm(FilmDomain filmDelete)
        {
            try
            {
                Film film1 = await _context.Film.FindAsync(filmDelete.FilmID);
                if (film1 != null)
                {
                    film1.Pristup = false;

                    _context.Entry(film1).State = EntityState.Modified;

                    await _context.SaveChangesAsync();
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }
        /*
        public async Task<IEnumerable<FilmDomain>> GetAllFilmsAsync()
        {
            return await _context.Film.Select(f => new FilmDomain
            {
                FilmID = f.FilmID,
                Naziv = f.Naziv,
                Opis = f.Opis,
                Slika = f.Slika,
                ZanrID = (int)f.ZanrID,
                Podudaranje = f.Podudaranje,
                Godina = f.Godina,
                Trajanje = f.Trajanje,
                Ogranicenje = f.Ogranicenje,
                Redatelji = f.Redatelji,
                Glumci = f.Glumci,
                Scenaristi = f.Scenaristi,
                Zanrovi = f.Zanrovi
            }).ToListAsync();
        }

        public async Task<FilmDomain> GetFilmByIdAsync(int id)
        {
            var film = await _context.Film.FindAsync(id);
            if (film == null)
            {
                return null;
            }

            return new FilmDomain
            {
                FilmID = film.FilmID,
                Naziv = film.Naziv,
                Opis = film.Opis,
                Slika = film.Slika,
                ZanrID = (int)film.ZanrID,
                Podudaranje = film.Podudaranje,
                Godina = film.Godina,
                Trajanje = film.Trajanje,
                Ogranicenje = film.Ogranicenje,
                Redatelji = film.Redatelji,
                Glumci = film.Glumci,
                Scenaristi = film.Scenaristi,
                Zanrovi = film.Zanrovi
            };
        }
        public async Task AddFilmAsync(Film film)
        {
            await _context.Film.AddAsync(film);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateFilmAsync(Film film)
        {
            _context.Film.Update(film);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteFilmAsync(int id)
        {
            var film = await _context.Film.FindAsync(id);
            if (film != null)
            {
                _context.Film.Remove(film);
                await _context.SaveChangesAsync();
            }
        }
        */
    }
}
