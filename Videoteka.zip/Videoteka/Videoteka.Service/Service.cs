﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Videoteka.Model;
using Videoteka.DataModel;
using Videoteka.Repository.Common;
using Videoteka.Service.Common;

namespace Videoteka.Service
{
    public class Service : IService
    {
        readonly IRepository _repository;

        public Service(IRepository repository)
        {
            _repository = repository;
        }


        //ISPIS DOMENA
        public IEnumerable<OsobaDomain> GetAllOsoba()
        {
            IEnumerable<OsobaDomain> osoba = _repository.GetAllOsoba();
            return osoba;
        }
        public IEnumerable<GledateljDomain> GetAllGledatelj()
        {
            IEnumerable<GledateljDomain> gledatelj = _repository.GetAllGledatelj();
            return gledatelj;
        }
        public IEnumerable<AdministratorDomain> GetAllAdministrator()
        {
            IEnumerable<AdministratorDomain> administrator = _repository.GetAllAdministrator();
            return administrator;
        }
        public IEnumerable<ZanrDomain> GetAllZanr()
        {
            IEnumerable<ZanrDomain> zanr = _repository.GetAllZanr();
            return zanr;
        }
        public IEnumerable<FilmDomain> GetAllFilm()
        {
            IEnumerable<FilmDomain> film = _repository.GetAllFilm();
            return film;
        }
        public IEnumerable<FilmDomain> GetAllFilmRandom()
        {
            IEnumerable<FilmDomain> filmRandom = _repository.GetAllFilmRandom();
            return filmRandom;
        }
        public IEnumerable<SkladisteDomain> GetAllSkladiste()
        {
            IEnumerable<SkladisteDomain> skladiste = _repository.GetAllSkladiste();
            return skladiste;
        }
        public IEnumerable<ZapisiDomain> GetAllZapisi()
        {
            IEnumerable<ZapisiDomain> zapisi = _repository.GetAllZapisi();
            return zapisi;
        }


        //ISPIS PO ID-U
        public OsobaDomain GetOsobaById(int osobaId)
        {
            OsobaDomain osobaDomain = _repository.GetOsobaById(osobaId);
            return osobaDomain;
        }
        public GledateljDomain GetGledateljById(int gledateljId)
        {
            GledateljDomain gledateljDomain = _repository.GetGledateljById(gledateljId);
            return gledateljDomain;
        }
        public AdministratorDomain GetAdministratorById(int administratorId)
        {
            AdministratorDomain administratorDomain = _repository.GetAdministratorById(administratorId);
            return administratorDomain;
        }
        public ZanrDomain GetZanrById(int zanrId)
        {
            ZanrDomain zanrDomain = _repository.GetZanrById(zanrId);
            return zanrDomain;
        }
        public FilmDomain GetFilmById(int filmId)
        {
            FilmDomain filmDomain = _repository.GetFilmById(filmId);
            return filmDomain;
        }
        public FilmDomain GetFilmByZanrId(int filmZanrId)
        {
            FilmDomain filmZanrDomain = _repository.GetFilmByZanrId(filmZanrId);
            return filmZanrDomain;
        }
        public FilmDomain GetFilmByIdAndZanrId(int zanrId, int filmId)
        {
            FilmDomain filmZanrIdDomain = _repository.GetFilmByIdAndZanrId(zanrId, filmId);
            return filmZanrIdDomain;
        }
        public SkladisteDomain GetSkladisteById(int skladisteId)
        {
            SkladisteDomain skladisteDomain = _repository.GetSkladisteById(skladisteId);
            return skladisteDomain;
        }
        public SkladisteDomain GetSkladisteByFilmId(int skladisteFilmId)
        {
            SkladisteDomain skladisteFilmDomain = _repository.GetSkladisteByFilmId(skladisteFilmId);
            return skladisteFilmDomain;
        }
        public SkladisteDomain GetSkladisteByKolicina(int skladisteKolicina)
        {
            SkladisteDomain skladisteKolicinaDomain = _repository.GetSkladisteByKolicina(skladisteKolicina);
            return skladisteKolicinaDomain;
        }
        public ZapisiDomain GetZapisiById(int zapisiId)
        {
            ZapisiDomain zapisiDomain = _repository.GetZapisiById(zapisiId);
            return zapisiDomain;
        }
        public ZapisiDomain GetZapisiByFilmId(int zapisiFilmId)
        {
            ZapisiDomain zapisiFilmDomain = _repository.GetZapisiByFilmId(zapisiFilmId);
            return zapisiFilmDomain;
        }
        public ZapisiDomain GetZapisiByGledateljId(int zapisiGledateljId)
        {
            ZapisiDomain zapisiGledateljDomain = _repository.GetZapisiByGledateljId(zapisiGledateljId);
            return zapisiGledateljDomain;
        }
        public ZapisiDomain GetZapisiByVrijemeIzdavanja(DateTime zapisiVrijemeIzdavanja)
        {
            ZapisiDomain zapisiIzdavanjeDomain = _repository.GetZapisiByVrijemeIzdavanja(zapisiVrijemeIzdavanja);
            return zapisiIzdavanjeDomain;
        }
        public ZapisiDomain GetZapisiByVrijemePovrata(string zapisiVrijemePovrata)
        {
            ZapisiDomain zapisiPovratDomain = _repository.GetZapisiByVrijemePovrata(zapisiVrijemePovrata);
            return zapisiPovratDomain;
        }


        //DODAVANJE
        public async Task<bool> DodajOsoba(OsobaDomain osobaAdd)
        {
            return await _repository.DodajOsoba(osobaAdd);
        }
        public async Task<bool> DodajOsobaGledatelj(OsobaDomain osobaAddGledatelj)
        {
            return await _repository.DodajOsobaGledatelj(osobaAddGledatelj);
        }
        public async Task<bool> DodajOsobaAdministrator(OsobaDomain osobaAddAdministrator)
        {
            return await _repository.DodajOsobaAdministrator(osobaAddAdministrator);
        }
        public async Task<bool> DodajGledatelj(GledateljDomain gledateljAdd)
        {
            return await _repository.DodajGledatelj(gledateljAdd);
        }
        public async Task<bool> DodajAdministrator(AdministratorDomain administratorAdd)
        {
            return await _repository.DodajAdministrator(administratorAdd);
        }
        public async Task<bool> DodajFilm(FilmDomain filmAdd)
        {
            return await _repository.DodajFilm(filmAdd);
        }
        public async Task<bool> DodajSkladiste(SkladisteDomain skladisteAdd)
        {
            return await _repository.DodajSkladiste(skladisteAdd);
        }
        public async Task<bool> DodajZapisi(ZapisiDomain zapisiAdd)
        {
            return await _repository.DodajZapisi(zapisiAdd);
        }


        //AZURIRANJE
        public async Task<bool> UpdateOsoba(OsobaDomain osobaUpdate)
        {
            return await _repository.UpdateOsoba(osobaUpdate);
        }
        public async Task<bool> UpdateGledatelj(GledateljDomain gledateljUpdate)
        {
            return await _repository.UpdateGledatelj(gledateljUpdate);
        }
        public async Task<bool> UpdateAdministrator(AdministratorDomain administratorUpdate)
        {
            return await _repository.UpdateAdministrator(administratorUpdate);
        }
        public async Task<bool> UpdateFilm(FilmDomain filmUpdate)
        {
            return await _repository.UpdateFilm(filmUpdate);
        }
        public async Task<bool> UpdateSkladiste(SkladisteDomain skladisteUpdate)
        {
            return await _repository.UpdateSkladiste(skladisteUpdate);
        }
        public async Task<bool> UpdateZapisi(ZapisiDomain zapisiUpdate)
        {
            return await _repository.UpdateZapisi(zapisiUpdate);
        }


        //BRISANJE
        public async Task<bool> DeleteOsoba(OsobaDomain osobaDelete)
        {
            return await _repository.DeleteOsoba(osobaDelete);
        }
        public async Task<bool> DeleteFilm(FilmDomain filmDelete)
        {
            return await _repository.DeleteFilm(filmDelete);
        }
    }
}
