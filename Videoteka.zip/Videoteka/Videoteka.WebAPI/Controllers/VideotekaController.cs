﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Videoteka.DataModel;
using Videoteka.Model;
using Videoteka.Service.Common;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Videoteka.Repository.Automapper;
using Videoteka.WebAPI.Controllers.RESTModel;
using Newtonsoft.Json;

namespace Videoteka.WebAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class VideotekaController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly VideotekaDbContext _context;
        private readonly IRepositoryMappingService _mappingService;
        protected IService _service { get; private set; }

        public VideotekaController(IService service, IConfiguration configuration, VideotekaDbContext context, IRepositoryMappingService mappingService)
        {
            _service = service;
            _configuration = configuration;
            _context = context;
            _mappingService = mappingService;
        }


        //ISPIS DOMENA
        [HttpGet]
        [Route("osobe")]
        [AllowAnonymous]
        public IEnumerable<OsobaDomain> GetAllOsoba()
        {
            IEnumerable<OsobaDomain> osoba = _service.GetAllOsoba();
            return osoba;
        }
        [HttpGet]
        [Route("gledatelji")]
        [AllowAnonymous]
        public IEnumerable<GledateljDomain> GetAllGledatelj()
        {
            IEnumerable<GledateljDomain> gledatelj = _service.GetAllGledatelj();
            return gledatelj;
        }
        [HttpGet]
        [Route("administratori")]
        [AllowAnonymous]
        public IEnumerable<AdministratorDomain> GetAllAdministrator()
        {
            IEnumerable<AdministratorDomain> administrator = _service.GetAllAdministrator();
            return administrator;
        }
        [HttpGet]
        [Route("zanr")]
        [AllowAnonymous]
        public IEnumerable<ZanrDomain> GetAllZanr()
        {
            IEnumerable<ZanrDomain> zanr = _service.GetAllZanr();
            return zanr;
        }
        [HttpGet]
        [Route("filmovi/svi")]
        [AllowAnonymous]
        public IEnumerable<FilmDomain> GetAllFilm()
        {
            IEnumerable<FilmDomain> film = _service.GetAllFilm();
            return film;
        }
        [HttpGet]
        [Route("filmovi")]
        [AllowAnonymous]
        public IEnumerable<FilmDomain> GetAllFilmRandom()
        {
            IEnumerable<FilmDomain> filmRandom = _service.GetAllFilmRandom();
            return filmRandom;
        }
        [HttpGet]
        [Route("skladiste")]
        [AllowAnonymous]
        public IEnumerable<SkladisteDomain> GetAllSkladiste()
        {
            IEnumerable<SkladisteDomain> skladiste = _service.GetAllSkladiste();
            return skladiste;
        }
        [HttpGet]
        [Route("zapis")]
        [AllowAnonymous]
        public IEnumerable<ZapisiDomain> GetAllZapisi()
        {
            IEnumerable<ZapisiDomain> zapisi = _service.GetAllZapisi();
            return zapisi;
        }


        //ISPIS PO ID-U
        [HttpGet]
        [Route("osobe/{osobaId}")]
        [AllowAnonymous]
        public OsobaDomain GetOsobaById(int osobaId)
        {
            OsobaDomain osobaDomain = _service.GetOsobaById(osobaId);
            return osobaDomain;
        }
        [HttpGet]
        [Route("gledatelji/{gledateljId}")]
        [AllowAnonymous]
        public GledateljDomain GetGledateljById(int gledateljId)
        {
            GledateljDomain gledateljDomain = _service.GetGledateljById(gledateljId);
            return gledateljDomain;
        }
        [HttpGet]
        [Route("administratori/{administratorId}")]
        [AllowAnonymous]
        public AdministratorDomain GetAdministratorById(int administratorId)
        {
            AdministratorDomain administratorDomain = _service.GetAdministratorById(administratorId);
            return administratorDomain;
        }
        [HttpGet]
        [Route("zanr/{zanrId}")]
        [AllowAnonymous]
        public ZanrDomain GetZanrById(int zanrId)
        {
            ZanrDomain zanrDomain = _service.GetZanrById(zanrId);
            return zanrDomain;
        }
        [HttpGet]
        [Route("filmovi/{filmId}")]
        [AllowAnonymous]
        public FilmDomain GetFilmById(int filmId)
        {
            FilmDomain filmDomain = _service.GetFilmById(filmId);
            return filmDomain;
        }
        [HttpGet]
        [Route("filmovi/zanr/{filmZanrId}")]
        [AllowAnonymous]
        public FilmDomain GetFilmByZanrId(int filmZanrId)
        {
            FilmDomain filmZanrDomain = _service.GetFilmByZanrId(filmZanrId);
            return filmZanrDomain;
        }
        [HttpGet]
        [Route("filmovi/zanr/{zanrId}/{filmId}")]
        [AllowAnonymous]
        public FilmDomain GetFilmByIdAndZanrId(int zanrId, int filmId)
        {
            FilmDomain filmZanrIdDomain = _service.GetFilmByIdAndZanrId(zanrId, filmId);
            return filmZanrIdDomain;
        }
        [HttpGet]
        [Route("skladiste/{skladisteId}")]
        [AllowAnonymous]
        public SkladisteDomain GetSkladisteById(int skladisteId)
        {
            SkladisteDomain skladisteDomain = _service.GetSkladisteById(skladisteId);
            return skladisteDomain;
        }
        [HttpGet]
        [Route("skladiste/film/{skladisteFilmId}")]
        [AllowAnonymous]
        public SkladisteDomain GetSkladisteByFilmId(int skladisteFilmId)
        {
            SkladisteDomain skladisteFilmDomain = _service.GetSkladisteByFilmId(skladisteFilmId);
            return skladisteFilmDomain;
        }
        [HttpGet]
        [Route("skladiste/kolicina/{skladisteKolicina}")]
        [AllowAnonymous]
        public SkladisteDomain GetSkladisteByKolicina(int skladisteKolicina)
        {
            SkladisteDomain skladisteKolicinaDomain = _service.GetSkladisteByKolicina(skladisteKolicina);
            return skladisteKolicinaDomain;
        }
        [HttpGet]
        [Route("zapis/{zapisiId}")]
        [AllowAnonymous]
        public ZapisiDomain GetZapisiById(int zapisiId)
        {
            ZapisiDomain zapisiDomain = _service.GetZapisiById(zapisiId);
            return zapisiDomain;
        }
        [HttpGet]
        [Route("zapis/film/{zapisiFilmId}")]
        [AllowAnonymous]
        public ZapisiDomain GetZapisiByFilmId(int zapisiFilmId)
        {
            ZapisiDomain zapisiFilmDomain = _service.GetZapisiByFilmId(zapisiFilmId);
            return zapisiFilmDomain;
        }
        [HttpGet]
        [Route("zapis/gledatelj/{zapisiGledateljId}")]
        [AllowAnonymous]
        public ZapisiDomain GetZapisiByGledateljId(int zapisiGledateljId)
        {
            ZapisiDomain zapisiGledateljDomain = _service.GetZapisiByGledateljId(zapisiGledateljId);
            return zapisiGledateljDomain;
        }
        [HttpGet]
        [Route("zapis/izdavanje/{zapisiVrijemeIzdavanja}")]
        [AllowAnonymous]
        public ZapisiDomain GetZapisiByVrijemeIzdavanja(DateTime zapisiVrijemeIzdavanja)
        {
            ZapisiDomain zapisiIzdavanjeDomain = _service.GetZapisiByVrijemeIzdavanja(zapisiVrijemeIzdavanja);
            return zapisiIzdavanjeDomain;
        }
        [HttpGet]
        [Route("zapis/povrat/{zapisiVrijemePovrata}")]
        [AllowAnonymous]
        public ZapisiDomain GetZapisiByVrijemePovrata(string zapisiVrijemePovrata)
        {
            ZapisiDomain zapisiPovratDomain = _service.GetZapisiByVrijemePovrata(zapisiVrijemePovrata);
            return zapisiPovratDomain;
        }


        [HttpPost]
        [Route("osobe/login")]
        [AllowAnonymous]
        public ActionResult<OsobaDomain> Login([FromBody] LoginRequest request)
        {
            Osoba osoba = _context.Osoba.FirstOrDefault(o => o.Email == request.Email && o.Lozinka == request.Password);

            if (osoba != null)
            {
                var osobaDomain = _mappingService.Map<IEnumerable<OsobaDomain>>(osoba);
                return Ok(osobaDomain);
            }
            else
            {
                return Unauthorized(); // Return HTTP 401 if credentials are invalid
            }
        }


        //DODAVANJE
        [HttpPost]
        [Route("osobe/dodaj")]
        [AllowAnonymous]
        public async Task<IActionResult> DodajOsoba([FromBody] OsobaDomain osobaAdd)
        {
            try
            {
                bool dodaj_osoba = await _service.DodajOsoba(osobaAdd);
                if (dodaj_osoba)
                {
                    return Ok("Osoba dodana");
                }
                else
                {
                    return Ok("Osoba nije dodana");
                }
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, e.ToString()); ;
            }
        }
        [HttpPost]
        [Route("osobe/dodajGledatelj")]
        [AllowAnonymous]
        public async Task<IActionResult> DodajOsobaGledatelj([FromBody] OsobaDomain osobaAddGledatelj)
        {
            try
            {
                bool dodaj_osobaGledatelj = await _service.DodajOsobaGledatelj(osobaAddGledatelj);
                if (dodaj_osobaGledatelj)
                {
                    return Ok("Osoba dodana i u Gledatelje");
                }
                else
                {
                    return Ok("Osoba nije dodana ni u Gledatelje");
                }
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, e.ToString()); ;
            }
        }
        [HttpPost]
        [Route("osobe/dodajAdministrator")]
        [AllowAnonymous]
        public async Task<IActionResult> DodajOsobaAdministrator([FromBody] OsobaDomain osobaAddAdministrator)
        {
            try
            {
                bool dodaj_osobaAdministrator = await _service.DodajOsobaAdministrator(osobaAddAdministrator);
                if (dodaj_osobaAdministrator)
                {
                    return Ok("Osoba dodana i u Administratore");
                }
                else
                {
                    return Ok("Osoba nije dodana ni u Administratore");
                }
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, e.ToString()); ;
            }
        }
        [HttpPost]
        [Route("gledatelji/dodaj")]
        [AllowAnonymous]
        public async Task<IActionResult> DodajGledatelj([FromBody] GledateljDomain gledateljAdd)
        {
            try
            {
                bool dodaj_Gledatelj = await _service.DodajGledatelj(gledateljAdd);
                if (dodaj_Gledatelj)
                {
                    return Ok("Gledatelj dodan");
                }
                else
                {
                    return Ok("Gledatelj nije dodan");
                }
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, e.ToString()); ;
            }
        }
        [HttpPost]
        [Route("administratori/dodaj")]
        [AllowAnonymous]
        public async Task<IActionResult> DodajAdministrator([FromBody] AdministratorDomain administratorAdd)
        {
            try
            {
                bool dodaj_Administrator = await _service.DodajAdministrator(administratorAdd);
                if (dodaj_Administrator)
                {
                    return Ok("Administrator dodan");
                }
                else
                {
                    return Ok("Administrator nije dodan");
                }
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, e.ToString()); ;
            }
        }
        [HttpPost]
        [Route("filmovi/dodaj")]
        [AllowAnonymous]
        public async Task<IActionResult> DodajFilm([FromBody] FilmDomain filmAdd)
        {
            try
            {
                bool dodaj_film = await _service.DodajFilm(filmAdd);
                if (dodaj_film)
                {
                    return Ok("Film dodan");
                }
                else
                {
                    return Ok("Film nije dodan");
                }
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, e.ToString()); ;
            }
        }
        [HttpPost]
        [Route("skladiste/dodaj")]
        [AllowAnonymous]
        public async Task<IActionResult> DodajSkladiste([FromBody] SkladisteDomain skladisteAdd)
        {
            try
            {
                bool dodaj_skladiste = await _service.DodajSkladiste(skladisteAdd);
                if (dodaj_skladiste)
                {
                    return Ok("Dodan u skladiste");
                }
                else
                {
                    return Ok("Nije dodan u skladiste");
                }
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, e.ToString()); ;
            }
        }
        [HttpPost]
        [Route("zapis/dodaj")]
        [AllowAnonymous]
        public async Task<IActionResult> DodajZapisi([FromBody] ZapisiDomain zapisiAdd)
        {
            try
            {
                bool dodaj_zapisi = await _service.DodajZapisi(zapisiAdd);
                if (dodaj_zapisi)
                {
                    return Ok("Dodan u zapise");
                }
                else
                {
                    return Ok("Nije dodan u zapise");
                }
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, e.ToString()); ;
            }
        }


        //AZURIRANJE
        [HttpPut]
        [Route("osobe/azuriraj")]
        [AllowAnonymous]
        public async Task<IActionResult> UpdateOsoba([FromBody] OsobaDomain osobaUpdate)
        {
            try
            {
                if (osobaUpdate == null || !ModelState.IsValid)
                {
                    return BadRequest("Invalid data.");
                }
                bool update_osoba = await _service.UpdateOsoba(osobaUpdate);
                if (update_osoba)
                {
                    return Ok();
                }
                return BadRequest("Update failed.");
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, e.ToString()); ;
            }
        }
        [HttpPut]
        [Route("gledatelji/azuriraj")]
        [AllowAnonymous]
        public async Task<IActionResult> UpdateGledatelj([FromBody] GledateljDomain gledateljUpdate)
        {
            try
            {
                if (gledateljUpdate == null || !ModelState.IsValid)
                {
                    return BadRequest("Invalid data.");
                }
                bool update_gledatelj = await _service.UpdateGledatelj(gledateljUpdate);
                if (update_gledatelj)
                {
                    return Ok();
                }
                return BadRequest("Update failed.");
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, e.ToString()); ;
            }
        }
        [HttpPut]
        [Route("administratori/azuriraj")]
        [AllowAnonymous]
        public async Task<IActionResult> UpdateAdministrator([FromBody] AdministratorDomain administratorUpdate)
        {
            try
            {
                if (administratorUpdate == null || !ModelState.IsValid)
                {
                    return BadRequest("Invalid data.");
                }
                bool update_administrator = await _service.UpdateAdministrator(administratorUpdate);
                if (update_administrator)
                {
                    return Ok();
                }
                return BadRequest("Update failed.");
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, e.ToString()); ;
            }
        }
        [HttpPut]
        [Route("filmovi/azuriraj")]
        [AllowAnonymous]
        public async Task<IActionResult> UpdateFilm([FromBody] FilmDomain filmUpdate)
        {
            try
            {
                if (filmUpdate == null || !ModelState.IsValid)
                {
                    return BadRequest("Invalid data.");
                }
                bool update_film = await _service.UpdateFilm(filmUpdate);
                if (update_film)
                {
                    return Ok();
                }
                return BadRequest("Update failed.");
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, e.ToString()); ;
            }
        }
        [HttpPut]
        [Route("skladiste/azuriraj")]
        [AllowAnonymous]
        public async Task<IActionResult> UpdateSkladiste([FromBody] SkladisteDomain skladisteUpdate)
        {
            try
            {
                if (skladisteUpdate == null || !ModelState.IsValid)
                {
                    return BadRequest("Invalid data.");
                }
                bool update_skladiste = await _service.UpdateSkladiste(skladisteUpdate);
                if (update_skladiste)
                {
                    return Ok();
                }
                return BadRequest("Update failed.");
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, e.ToString()); ;
            }
        }
        [HttpPut]
        [Route("zapis/azuriraj")]
        [AllowAnonymous]
        public async Task<IActionResult> UpdateZapisi([FromBody] ZapisiDomain zapisiUpdate)
        {
            try
            {
                if (zapisiUpdate == null || !ModelState.IsValid)
                {
                    return BadRequest("Invalid data.");
                }
                bool update_zapisi = await _service.UpdateZapisi(zapisiUpdate);
                if (update_zapisi)
                {
                    return Ok();
                }
                return BadRequest("Update failed.");
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, e.ToString()); ;
            }
        }


        //BRISANJE
        [HttpPut]
        [Route("osobe/brisanje")]
        [AllowAnonymous]
        public async Task<IActionResult> DeleteOsoba([FromBody] OsobaDomain osobaDelete)
        {
            try
            {
                if (osobaDelete == null || !ModelState.IsValid)
                {
                    return BadRequest("Invalid data.");
                }
                bool delete_osoba = await _service.DeleteOsoba(osobaDelete);
                if (delete_osoba)
                {
                    return Ok();
                }
                return BadRequest("Delete failed.");
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, e.ToString()); ;
            }
        }
        [HttpPut]
        [Route("filmovi/brisanje")]
        [AllowAnonymous]
        public async Task<IActionResult> DeleteFilm([FromBody] FilmDomain filmDelete)
        {
            try
            {
                if (filmDelete == null || !ModelState.IsValid)
                {
                    return BadRequest("Invalid data.");
                }
                bool delete_film = await _service.DeleteFilm(filmDelete);
                if (delete_film)
                {
                    return Ok();
                }
                return BadRequest("Delete failed.");
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, e.ToString()); ;
            }
        }
        /*
        [HttpPost]
        public async Task<IActionResult> AddFilm([FromBody] Film film)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var filmDomain = new FilmDomain
            {
                FilmID = film.FilmID,
                Naziv = film.Naziv,
                Opis = film.Opis,
                ZanrID = (int)film.ZanrID,
                Podudaranje = film.Podudaranje,
                Godina = film.Godina,
                Trajanje = film.Trajanje,
                Ogranicenje = film.Ogranicenje,
                Redatelji = film.Redatelji,
                Glumci = film.Glumci,
                Scenaristi = film.Scenaristi,
                Zanrovi = film.Zanrovi
            };

            await _filmService.AddAsync(filmDomain);
            return CreatedAtAction(nameof(GetFilmById), new { id = film.FilmID }, filmDomain);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateFilm(int id, [FromBody] Film film)
        {
            if (id != film.FilmID)
            {
                return BadRequest();
            }

            var filmDomain = new FilmDomain
            {
                FilmID = film.FilmID,
                Naziv = film.Naziv,
                Opis = film.Opis,
                ZanrID = (int)film.ZanrID,
                Podudaranje = film.Podudaranje,
                Godina = film.Godina,
                Trajanje = film.Trajanje,
                Ogranicenje = film.Ogranicenje,
                Redatelji = film.Redatelji,
                Glumci = film.Glumci,
                Scenaristi = film.Scenaristi,
                Zanrovi = film.Zanrovi
            };

            await _filmService.UpdateAsync(filmDomain);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteFilm(int id)
        {
            await _filmService.DeleteAsync(id);
            return NoContent();
        }

        [HttpGet("filmovi")]
        public async Task<ActionResult<IEnumerable<FilmDomain>>> GetAllFilms()
        {
            var films = await _filmService.GetAllAsync();
            return Ok(films);
        }

        [HttpGet("filmovi/{id}")]
        public async Task<ActionResult<FilmDomain>> GetFilmById(int id)
        {
            var film = await _filmService.GetByIdAsync(id);
            if (film == null)
            {
                return NotFound();
            }
            return Ok(film);
        }

        [HttpGet("filmovi/zanr/{zanrId}")]
        public async Task<ActionResult<IEnumerable<FilmDomain>>> GetFilmsByZanr(int zanrId)
        {
            var films = await _filmService.GetFilmsByZanrAsync(zanrId);
            return Ok(films);
        }

        [HttpGet("filmovi/zanr/{zanrId}/{filmId}")]
        public async Task<ActionResult<FilmDomain>> GetFilmByZanrAndId(int zanrId, int filmId)
        {
            var film = await _filmService.GetFilmByZanrAndIdAsync(zanrId, filmId);
            if (film == null)
            {
                return NotFound();
            }
            return Ok(film);
        }
        /*
        [HttpGet("racun")]
        public async Task<ActionResult<OsobaDomain>> GetCurrentOsoba()
        {
            var osoba = await _administratorService.GetCurrentOsobaAsync() ?? await _gledateljService.GetCurrentOsobaAsync();
            if (osoba == null)
            {
                return NotFound();
            }
            return Ok(osoba);
        }
        *//*
        [HttpGet("skladiste")]
        public async Task<ActionResult<IEnumerable<SkladisteDomain>>> GetAllSkladiste()
        {
            var skladiste = await _skladisteService.GetAllAsync();
            return Ok(skladiste);
        }

        [HttpGet("skladiste/film/{filmId}")]
        public async Task<ActionResult<IEnumerable<SkladisteDomain>>> GetSkladisteByFilmId(int filmId)
        {
            var skladiste = await _skladisteService.GetByFilmIDAsync(filmId);
            return Ok(skladiste);
        }

        [HttpGet("skladiste/{kolicina}")]
        public async Task<ActionResult<IEnumerable<SkladisteDomain>>> GetSkladisteByKolicina(int kolicina)
        {
            var skladiste = await _skladisteService.GetByKolicinaAsync(kolicina);
            return Ok(skladiste);
        }

        [HttpGet("zapisi")]
        public async Task<ActionResult<IEnumerable<ZapisiDomain>>> GetAllZapisi()
        {
            var zapisi = await _zapisiService.GetAllAsync();
            return Ok(zapisi);
        }

        [HttpGet("zapisi/film/{filmId}")]
        public async Task<ActionResult<IEnumerable<ZapisiDomain>>> GetZapisiByFilmId(int filmId)
        {
            var zapisi = await _zapisiService.GetByFilmIDAsync(filmId);
            return Ok(zapisi);
        }

        [HttpGet("zapisi/gledatelj/{gledateljId}")]
        public async Task<ActionResult<IEnumerable<ZapisiDomain>>> GetZapisiByGledateljId(int gledateljId)
        {
            var zapisi = await _zapisiService.GetByGledateljIDAsync(gledateljId);
            return Ok(zapisi);
        }

        [HttpGet("zapisi/izdavanje/{vrijemeIzdavanja}")]
        public async Task<ActionResult<IEnumerable<ZapisiDomain>>> GetZapisiByVrijemeIzdavanja(DateTime vrijemeIzdavanja)
        {
            var zapisi = await _zapisiService.GetByVrijemeIzdavanjaAsync(vrijemeIzdavanja);
            return Ok(zapisi);
        }

        [HttpGet("zapisi/povrata/{vrijemePovrata}")]
        public async Task<ActionResult<IEnumerable<ZapisiDomain>>> GetZapisiByVrijemePovrata(string vrijemePovrata)
        {
            var zapisi = await _zapisiService.GetByVrijemePovrataAsync(vrijemePovrata);
            return Ok(zapisi);
        }*/
    }
}
