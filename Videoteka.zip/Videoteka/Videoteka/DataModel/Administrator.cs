﻿using System;
using System.Collections.Generic;

namespace Videoteka.DataModel
{
    public partial class Administrator
    {
        public int AdministratorID { get; set; }
        public int? OsobaID { get; set; }
        public DateTime? DatumZaposlenja { get; set; }

        public virtual Osoba Osoba { get; set; }
    }
}
