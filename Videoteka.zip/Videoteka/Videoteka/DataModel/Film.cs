﻿using System;
using System.Collections.Generic;

namespace Videoteka.DataModel
{
    public partial class Film
    {
        public Film()
        {
            Skladiste = new HashSet<Skladiste>();
            Zapisi = new HashSet<Zapisi>();
        }

        public int FilmID { get; set; }
        public bool Pristup { get; set; }
        public string Naziv { get; set; }
        public string Opis { get; set; }
        public int? ZanrID { get; set; }
        public string Podudaranje { get; set; }
        public string Godina { get; set; }
        public string Trajanje { get; set; }
        public string Ogranicenje { get; set; }
        public string Redatelji { get; set; }
        public string Glumci { get; set; }
        public string Scenaristi { get; set; }
        public string Zanrovi { get; set; }

        public virtual Zanr Zanr { get; set; }
        public virtual ICollection<Skladiste> Skladiste { get; set; }
        public virtual ICollection<Zapisi> Zapisi { get; set; }
    }
}
