﻿using System;
using System.Collections.Generic;

namespace Videoteka.DataModel
{
    public partial class Gledatelj
    {
        public int GledateljID { get; set; }
        public int? OsobaID { get; set; }
        public DateTime? DatumRegistracije { get; set; }

        public virtual Osoba Osoba { get; set; }
        public virtual ICollection<Zapisi> Zapisi { get; set; } = new HashSet<Zapisi>();
    }
}
