﻿using System;
using System.Collections.Generic;

namespace Videoteka.DataModel
{
    public partial class Osoba
    {
        public int OsobaID { get; set; }
        public bool Pristup { get; set; }
        public string Ime { get; set; }
        public string Prezime { get; set; }
        public string Email { get; set; }
        public string Lozinka { get; set; }
        public virtual ICollection<Administrator> Administrator { get; set; }
        public virtual ICollection<Gledatelj> Gledatelj { get; set; }
    }
}
