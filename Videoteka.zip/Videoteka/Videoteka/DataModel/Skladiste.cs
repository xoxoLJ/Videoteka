﻿using System;
using System.Collections.Generic;

namespace Videoteka.DataModel
{
    public partial class Skladiste
    {
        public int SkladisteID { get; set; }
        public int FilmID { get; set; }
        public int Kolicina { get; set; }

        public virtual Film Film { get; set; }
    }
}
