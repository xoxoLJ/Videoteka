﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Videoteka.DataModel
{
    public partial class VideotekaDbContext : DbContext
    {
        public VideotekaDbContext()
        {
        }

        public VideotekaDbContext(DbContextOptions<VideotekaDbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Administrator> Administrator { get; set; }
        public virtual DbSet<Film> Film { get; set; }
        public virtual DbSet<Gledatelj> Gledatelj { get; set; }
        public virtual DbSet<Osoba> Osoba { get; set; }
        public virtual DbSet<Skladiste> Skladiste { get; set; }
        public virtual DbSet<Zanr> Zanr { get; set; }
        public virtual DbSet<Zapisi> Zapisi { get; set; }
        /*
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=(LocalDb)\\MSSQLLocalDB;Database=VUVvideoteka;Integrated Security=True;");
            }
        }
        */
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Administrator>(entity =>
            {
                entity.Property(e => e.AdministratorID).HasColumnName("AdministratorID");

                entity.Property(e => e.DatumZaposlenja).HasColumnType("date");

                entity.Property(e => e.OsobaID).HasColumnName("OsobaID");

                entity.HasOne(d => d.Osoba)
                    .WithMany(p => p.Administrator)
                    .HasForeignKey(d => d.OsobaID)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Administrator_Osoba");
            });

            modelBuilder.Entity<Film>(entity =>
            {
                entity.Property(e => e.FilmID).HasColumnName("FilmID");

                entity.Property(e => e.Naziv)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.Property(e => e.Opis).HasColumnType("nvarchar(max)");

                entity.Property(e => e.ZanrID).HasColumnName("ZanrID");

                entity.Property(e => e.Podudaranje).HasColumnType("nvarchar(255)");
                entity.Property(e => e.Godina).HasColumnType("nvarchar(255)");
                entity.Property(e => e.Trajanje).HasColumnType("nvarchar(255)");
                entity.Property(e => e.Ogranicenje).HasColumnType("nvarchar(255)");
                entity.Property(e => e.Redatelji).HasColumnType("nvarchar(255)");
                entity.Property(e => e.Glumci).HasColumnType("nvarchar(255)");
                entity.Property(e => e.Scenaristi).HasColumnType("nvarchar(255)");
                entity.Property(e => e.Zanrovi).HasColumnType("nvarchar(255)");

                entity.HasOne(d => d.Zanr)
                    .WithMany(p => p.Film)
                    .HasForeignKey(d => d.ZanrID)
                    .HasConstraintName("FK_Film_Zanr");
            });

            modelBuilder.Entity<Gledatelj>(entity =>
            {
                entity.Property(e => e.GledateljID).HasColumnName("GledateljID");

                entity.Property(e => e.DatumRegistracije).HasColumnType("date");

                entity.Property(e => e.OsobaID).HasColumnName("OsobaID");

                entity.HasOne(d => d.Osoba)
                    .WithMany(p => p.Gledatelj)
                    .HasForeignKey(d => d.OsobaID)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Gledatelj_Osoba");
            });

            modelBuilder.Entity<Osoba>(entity =>
            {
                entity.ToTable("Osoba");

                entity.HasIndex(e => e.Email)
                    .HasName("UQ__Osoba__A9D1053474632A62")
                    .IsUnique();

                entity.Property(e => e.OsobaID).HasColumnName("OsobaID");

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.Property(e => e.Ime)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.Property(e => e.Prezime)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.Property(e => e.Lozinka)
                    .IsRequired()
                    .HasMaxLength(255);
            });

            modelBuilder.Entity<Skladiste>(entity =>
            {
                entity.Property(e => e.SkladisteID).HasColumnName("SkladisteID");

                entity.Property(e => e.FilmID).HasColumnName("FilmID");

                entity.Property(e => e.Kolicina).HasColumnName("Kolicina");

                entity.HasOne(d => d.Film)
                    .WithMany(p => p.Skladiste)
                    .HasForeignKey(d => d.FilmID)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Skladiste_Film");
            });

            modelBuilder.Entity<Zanr>(entity =>
            {
                entity.Property(e => e.ZanrID).HasColumnName("ZanrID");

                entity.Property(e => e.Naziv)
                    .IsRequired()
                    .HasMaxLength(255);
            });

            modelBuilder.Entity<Zapisi>(entity =>
            {
                entity.Property(e => e.ZapisID).HasColumnName("ZapisID");

                entity.Property(e => e.FilmID).HasColumnName("FilmID");

                entity.Property(e => e.GledateljID).HasColumnName("GledateljID");

                entity.Property(e => e.VrijemeIzdavanja).HasColumnType("datetime");

                entity.Property(e => e.VrijemePovrata).HasColumnType("nvarchar(50)");

                entity.HasOne(d => d.Film)
                    .WithMany(p => p.Zapisi)
                    .HasForeignKey(d => d.FilmID)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Zapisi_Film");

                entity.HasOne(d => d.Gledatelj)
                    .WithMany(p => p.Zapisi)
                    .HasForeignKey(d => d.GledateljID)
                    .HasConstraintName("FK_Zapisi_Gledatelj");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
