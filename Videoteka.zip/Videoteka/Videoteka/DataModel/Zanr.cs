﻿using System;
using System.Collections.Generic;

namespace Videoteka.DataModel
{
    public partial class Zanr
    {
        public Zanr()
        {
            Film = new HashSet<Film>();
        }

        public int ZanrID { get; set; }
        public string Naziv { get; set; }

        public virtual ICollection<Film> Film { get; set; }
    }
}
