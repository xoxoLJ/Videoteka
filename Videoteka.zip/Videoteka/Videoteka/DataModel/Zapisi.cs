﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Videoteka.DataModel
{
    public partial class Zapisi
    {
        [Key]
        public int ZapisID { get; set; }
        public int? FilmID { get; set; }
        public int? GledateljID { get; set; }
        public DateTime? VrijemeIzdavanja { get; set; }
        public string VrijemePovrata { get; set; }

        public virtual Film Film { get; set; }
        public virtual Gledatelj Gledatelj { get; set; }
    }
}
