﻿using System;
using System.Linq.Expressions;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Videoteka.Migrations
{
    public partial class Povezivanje : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Osoba",
                columns: table => new
                {
                    OsobaID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Pristup = table.Column<bool>(nullable: true),
                    Ime = table.Column<string>(maxLength: 255, nullable: false),
                    Prezime = table.Column<string>(maxLength: 255, nullable: false),
                    Email = table.Column<string>(maxLength: 255, nullable: false),
                    Lozinka = table.Column<string>(maxLength: 255, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Osoba", x => x.OsobaID);
                });

            migrationBuilder.CreateTable(
                name: "Zanr",
                columns: table => new
                {
                    ZanrID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Naziv = table.Column<string>(maxLength: 255, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Zanr", x => x.ZanrID);
                });

            migrationBuilder.CreateTable(
                name: "Administrator",
                columns: table => new
                {
                    AdministratorID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    OsobaID = table.Column<int>(nullable: true),
                    DatumZaposlenja = table.Column<DateTime>(type: "date", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Administrator", x => x.AdministratorID);
                    table.ForeignKey(
                        name: "FK_Administrator_Osoba",
                        column: x => x.AdministratorID,
                        principalTable: "Osoba",
                        principalColumn: "OsobaID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Gledatelj",
                columns: table => new
                {
                    GledateljID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    OsobaID = table.Column<int>(nullable: true),
                    DatumRegistracije = table.Column<DateTime>(type: "date", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Gledatelj", x => x.GledateljID);
                    table.ForeignKey(
                        name: "FK_Gledatelj_Osoba",
                        column: x => x.GledateljID,
                        principalTable: "Osoba",
                        principalColumn: "OsobaID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Film",
                columns: table => new
                {
                    FilmID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Pristup = table.Column<bool>(nullable: true),
                    Naziv = table.Column<string>(maxLength: 255, nullable: false),
                    Opis = table.Column<string>(nullable: true),
                    ZanrID = table.Column<int>(nullable: true),
                    Podudaranje = table.Column<string>(maxLength: 255, nullable: true),
                    Godina = table.Column<string>(maxLength: 255, nullable: true),
                    Trajanje = table.Column<string>(maxLength: 255, nullable: true),
                    Ogranicenje = table.Column<string>(maxLength: 255, nullable: true),
                    Redatelji = table.Column<string>(maxLength: 255, nullable: true),
                    Glumci = table.Column<string>(maxLength: 255, nullable: true),
                    Scenaristi = table.Column<string>(maxLength: 255, nullable: true),
                    Zanrovi = table.Column<string>(maxLength: 255, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Film", x => x.FilmID);
                    table.ForeignKey(
                        name: "FK_Film_Zanr",
                        column: x => x.ZanrID,
                        principalTable: "Zanr",
                        principalColumn: "ZanrID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Skladiste",
                columns: table => new
                {
                    SkladisteID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FilmID = table.Column<int>(nullable: false),
                    Kolicina = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Skladiste", x => x.SkladisteID);
                    table.ForeignKey(
                        name: "FK_Skladiste_Film",
                        column: x => x.FilmID,
                        principalTable: "Film",
                        principalColumn: "FilmID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Zapisi",
                columns: table => new
                {
                    ZapisID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FilmID = table.Column<int>(nullable: true),
                    GledateljID = table.Column<int>(nullable: true),
                    VrijemeIzdavanja = table.Column<DateTime>(type: "datetime", nullable: true),
                    VrijemePovrata = table.Column<string>(maxLength: 50, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Zapisi", x => x.ZapisID);
                    table.ForeignKey(
                        name: "FK_Zapisi_Film",
                        column: x => x.FilmID,
                        principalTable: "Film",
                        principalColumn: "FilmID",
                        onDelete: ReferentialAction.Restrict);

                    table.ForeignKey(
                        name: "FK_Zapisi_Gledatelj",
                        column: x => x.GledateljID,
                        principalTable: "Gledatelj",
                        principalColumn: "GledateljID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Film_ZanrID",
                table: "Film",
                column: "ZanrID");

            migrationBuilder.CreateIndex(
                name: "UQ__Osoba__A9D1053474632A62",
                table: "Osoba",
                column: "Email",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Skladiste_FilmID",
                table: "Skladiste",
                column: "FilmID");

            migrationBuilder.CreateIndex(
                name: "IX_Zapisi_FilmID",
                table: "Zapisi",
                column: "FilmID");

            migrationBuilder.CreateIndex(
                name: "IX_Zapisi_GledateljID",
                table: "Zapisi",
                column: "GledateljID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Administrator");

            migrationBuilder.DropTable(
                name: "Skladiste");

            migrationBuilder.DropTable(
                name: "Zapisi");

            migrationBuilder.DropTable(
                name: "Film");

            migrationBuilder.DropTable(
                name: "Gledatelj");

            migrationBuilder.DropTable(
                name: "Zanr");

            migrationBuilder.DropTable(
                name: "Osoba");
        }
    }
}
